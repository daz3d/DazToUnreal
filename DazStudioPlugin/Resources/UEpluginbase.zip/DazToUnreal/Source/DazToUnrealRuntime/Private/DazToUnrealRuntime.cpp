#include "DazToUnrealRuntime.h"

#define LOCTEXT_NAMESPACE "FDazToUnrealRuntimeModule"

void FDazToUnrealRuntimeModule::StartupModule()
{

}

void FDazToUnrealRuntimeModule::ShutdownModule()
{

}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FDazToUnrealRuntimeModule, DazToUnrealRuntime)